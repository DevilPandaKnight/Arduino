#include "Wave.h"
#include <cmath>
#include <cstdio>

CWave::CWave(void)
{
    // Init members
    memset(&m_Descriptor, 0, sizeof(_WAVEDESCR));
    memset(&m_Format, 0, sizeof(_WAVEFORMAT));
    m_lpData = NULL;
    m_dwSize = 0;
}

CWave::~CWave(void)
{
    free(m_lpData);
}

bool CWave::Load(char* lpszFilePath)
{
    bool bResult = false;

    // Load .WAV file
    FILE* file = fopen(lpszFilePath, "rb");
    if (file != NULL)
    {
        // Read .WAV descriptor
        fread(&m_Descriptor, sizeof(_WAVEDESCR), 1, file);

        // Check for valid .WAV file
        if (strncmp((char*)m_Descriptor.wave, "WAVE", 4) == 0)
        {
            // Read .WAV format
            fread(&m_Format, sizeof(_WAVEFORMAT), 1, file);

            // Check for valid .WAV file
            if ((strncmp((char*)m_Format.id, "fmt", 3) == 0) && (m_Format.format == 1))
            {
                // Read next chunk
                char id[4];
                uint32_t size;
                fread(id, sizeof(uint8_t), 4, file);
                fread(&size, sizeof(uint32_t), 1, file);
                uint32_t offset = ftell(file);

                // Read .WAV data
                uint8_t* lpTemp = (uint8_t*)malloc(m_Descriptor.size*sizeof(uint8_t));
                while (offset < m_Descriptor.size)
                {
                    // Check for .WAV data chunk
                    if (strncmp(id, "data", 4) == 0)
                    {
                        if (m_lpData == NULL)
                            m_lpData = (uint8_t*)malloc(size*sizeof(uint8_t));
                        else
                            m_lpData = (uint8_t*)realloc(m_lpData, (m_dwSize+size)*sizeof(uint8_t));
                        fread(m_lpData+m_dwSize, sizeof(uint8_t), size, file);
                        m_dwSize += size;
                    }
                    else
                        fread(lpTemp, sizeof(uint8_t), size, file);

                    // Read next chunk
                    fread(id, sizeof(uint8_t), 4, file);
                    fread(&size, sizeof(uint32_t), 1, file);
                    offset = ftell(file);
                }
                free(lpTemp);

                bResult = true;
            }
        }

        // Close .WAV file
        fclose(file);
    }

    return bResult;
}

void CWave::Create(uint32_t size, uint32_t sampleRate, uint16_t bitsPerSample, uint16_t channels)
{
    strncpy((char*)m_Descriptor.wave, "WAVE", 4);
    strncpy((char*)m_Descriptor.riff, "RIFF", 4);
    m_Descriptor.size = size;
    strncpy((char*)m_Format.id, "fmt", 3);
    m_Format.bitsPerSample = bitsPerSample;
    m_Format.channels = channels;
    m_Format.sampleRate = sampleRate;
    m_Format.format = 1;
    m_Format.byteRate = sampleRate * (bitsPerSample/8);
    m_Format.blockAlign = (bitsPerSample/8)*channels;
    m_dwSize = size;

    m_lpData = (uint8_t*)malloc(sizeof(uint8_t) * size);
}

bool CWave::Save(char* lpszFilePath)
{
    bool bResult = false;

    // Save .WAV file
    FILE* file = fopen(lpszFilePath, "wb");
    if (file != NULL)
    {
        // Save .WAV descriptor
        m_Descriptor.size = m_dwSize;
        fwrite(&m_Descriptor, sizeof(_WAVEDESCR), 1, file);

        // Save .WAV format
        fwrite(&m_Format, sizeof(_WAVEFORMAT), 1, file);

        // Write .WAV data
        uint8_t id[4] = {'d', 'a', 't', 'a'};
        fwrite(id, sizeof(uint8_t), 4, file);
        fwrite(&m_dwSize, sizeof(uint32_t), 1, file);
        fwrite(m_lpData, sizeof(uint8_t), m_dwSize, file);
        bResult = true;

        // Close .WAV file
        fclose(file);
    }

    return bResult;
}

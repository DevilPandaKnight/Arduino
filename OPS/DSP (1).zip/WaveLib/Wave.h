#ifndef WAVE_LIB_H
#define WAVE_LIB_H

#include <cstdint>
#include <cstdlib>
#include <cstring>

typedef struct __WAVEDESCR
{
	uint8_t riff[4];
	uint32_t size;
	uint8_t wave[4];
} _WAVEDESCR, *_LPWAVEDESCR;

typedef struct __WAVEFORMAT
{
	uint8_t id[4];
	uint32_t size;
	uint16_t format;
	uint16_t channels;
	uint32_t sampleRate;
	uint32_t byteRate;
	uint16_t blockAlign;
	uint16_t bitsPerSample;
} _WAVEFORMAT, *_LPWAVEFORMAT;

class CWave
{
public:
	CWave(void);
	virtual ~CWave(void);

public:
	// Public methods
	void Create(uint32_t size, uint32_t sampleRate, uint16_t bitsPerSample, uint16_t channels);
	bool Load(char* lpszFilePath);
	bool Save(char* lpszFilePath);
//	bool Mix(CWave& wave);
	bool IsValid()				{return (m_lpData != NULL);}
	uint8_t* GetData()			{return m_lpData;}
	uint32_t GetSize()				{return m_dwSize;}
	uint16_t GetChannels()			{return m_Format.channels;}
	uint32_t GetSampleRate()		{return m_Format.sampleRate;}
	uint16_t GetBitsPerSample()	{return m_Format.bitsPerSample;}

private:
	// Private members
	_WAVEDESCR m_Descriptor;
	_WAVEFORMAT m_Format;
	uint8_t* m_lpData;
	uint32_t m_dwSize;
};

#endif // WAVE_LIB_H

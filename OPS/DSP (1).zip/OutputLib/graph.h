#ifndef GRAPH_LIB_H
#define GRAPH_LIB_H

/** \brief Plot a bar graph of one value
 *
 * \param value The value to graph
 * \param minVal The lower bound on the input value
 * \param maxVal The upper bound on the input value
 * \param barWidth The width of the bar graph
 *
 */
void printBarGraph(int, int, int, int);

#endif // GRAPH_LIB_H

#include "graph.h"
#include <cstdio>

void printBarGraph(int value, int minVal, int maxVal, int barWidth)
{
    // Lerp the value to the width of the bar graph
    value = ((value-minVal)*barWidth)/(maxVal-minVal);

    // Print the leading |
    putc('|', stdout);

    // Print the leading spaces
    for(int i = 0; i < value; i++)
    {
        putc(' ', stdout);
    }

    // Print the value marker
    putc('#', stdout);

    // Print the trailing spaces
    for(int i = 0; i < (barWidth - value - 1); i++)
    {
        putc(' ', stdout);
    }

    // Print the trailing |
    putc('|', stdout);
}

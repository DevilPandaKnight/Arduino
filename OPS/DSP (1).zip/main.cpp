#include "WaveLib/Wave.h"
#include <cstdio>
#include <algorithm>
#include <cmath>
#include "OutputLib/graph.h"
#include "FFTLib/fft.h"

int main(void)
{
    CWave wave;

    // open the wav file
    wave.Load("sampleTwoTone.wav");

    // get a pointer to the audio data
    int16_t* data = (int16_t*)wave.GetData();

    // Calculate the number of samples in the file
    int sampleCount = wave.GetSize() / (wave.GetBitsPerSample() >> 3) / wave.GetChannels();

    // Reduce the volume by a factor of 2

    for(uint32_t i = 0; i < (sampleCount * wave.GetChannels()); i++)
    {
        // When we are operating on channel 0
        if(i % wave.GetChannels() == 0)
            data[i] *= 5;
    }

    wave.Save("output.wav");

    return 0;
}


